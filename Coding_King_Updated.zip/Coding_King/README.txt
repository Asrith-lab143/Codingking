CODING KING 👑

Open Coding_King/index.html in a modern browser.

Includes:
- Demo login/create account
- Dashboard and progress
- Python, HTML & CSS, JavaScript, Java, SQL
- Lessons and completion tracking
- Coding quiz
- Profile page
- Mobile-friendly design

This is a front-end prototype. Authentication uses browser localStorage; a production site needs secure server-side authentication and a database.
